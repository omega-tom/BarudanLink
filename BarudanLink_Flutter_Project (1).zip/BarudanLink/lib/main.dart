
import 'package:flutter/material.dart';

void main() => runApp(BarudanLinkApp());

class BarudanLinkApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BarudanLink',
      home: Scaffold(
        appBar: AppBar(title: Text('BarudanLink')),
        body: Center(
          child: ElevatedButton.icon(
            icon: Icon(Icons.send),
            label: Text('ส่งไฟล์ไปเครื่องปัก'),
            onPressed: () {},
          ),
        ),
      ),
    );
  }
}
